const { Keypair } = require("@solana/web3.js");

async function createAgent() {
  const agent = Keypair.generate();
  console.log("AI Agent created with public key:", agent.publicKey.toString());

  setTimeout(() => {
    console.log("AI Agent is now operational and interacting with the blockchain...");
  }, 2000);
}

module.exports = { createAgent };