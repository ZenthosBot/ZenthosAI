const solanaWeb3 = require("@solana/web3.js");

const connection = new solanaWeb3.Connection(solanaWeb3.clusterApiUrl("devnet"), "confirmed");

async function deployContract() {
  const payer = solanaWeb3.Keypair.generate();
  console.log("Deploying contract with wallet:", payer.publicKey.toString());
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      console.log("Contract deployed successfully!");
      resolve();
    }, 3000);
  });
}

module.exports = { deployContract };